<?php
class Producto {
    public $nombre;
    public $precio;

    public function __construct($nombre, $precio) {
        $this->nombre = $nombre;
        $this->precio = $precio;
    }

    public function mostrar() {
        echo "$this->nombre cuesta $this->precio €<br>";
    }
}

$p = new Producto("Ratón inalámbrico", 19.99);
$p->mostrar();
?>