<?php
class Persona {
    protected $nombre;

    public function __construct($nombre) {
        $this->nombre = $nombre;
    }

    public function saludar() {
        echo "Hola, soy $this->nombre<br>";
    }
}

class Estudiante extends Persona {
    private $curso;

    public function __construct($nombre, $curso) {
        parent::__construct($nombre);
        $this->curso = $curso;
    }

    public function mostrarCurso() {
        echo "$this->nombre está en el curso $this->curso<br>";
    }
}

$e = new Estudiante("Himar", 1);
$e->saludar();
$e->mostrarCurso();
?>