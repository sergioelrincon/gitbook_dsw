<?php
interface Enviable {
    public function enviar();
}

class Correo implements Enviable {
    public function enviar() {
        echo "Mensaje enviado por correo<br>";
    }
}

$obj = new Correo();
$obj->enviar();
?>