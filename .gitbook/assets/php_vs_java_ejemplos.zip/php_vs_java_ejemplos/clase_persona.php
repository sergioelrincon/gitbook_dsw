<?php
class Persona {
    private $nombre;

    public function __construct($nombre) {
        $this->nombre = $nombre;
    }

    public function saludar() {
        echo "Hola, soy $this->nombre<br>";
    }
}

$persona = new Persona("Noa");
$persona->saludar();
?>