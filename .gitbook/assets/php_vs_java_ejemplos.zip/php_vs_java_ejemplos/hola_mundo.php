<?php
echo "Hola mundo desde PHP";
?>