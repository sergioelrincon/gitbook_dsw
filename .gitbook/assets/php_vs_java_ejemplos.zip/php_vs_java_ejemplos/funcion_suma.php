<?php
function sumar($a, $b) {
    return $a + $b;
}

echo "Suma de 4 + 6 = " . sumar(4, 6);
?>