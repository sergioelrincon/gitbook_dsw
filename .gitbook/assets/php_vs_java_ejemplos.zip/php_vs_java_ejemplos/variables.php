<?php
$nombre = "Sergio";
$edad = 46;
$activo = true;

echo "Nombre: $nombre<br>";
echo "Edad: $edad<br>";
echo "¿Activo?: " . ($activo ? "Sí" : "No");
?>